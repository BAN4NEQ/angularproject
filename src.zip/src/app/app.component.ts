import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  tytul = "Witaj śmiertelniku";
  wiadomosc: string = "";
  indeks: number = 0;
  licznik : number = 0;

  komunikaty: string[] = [
    "Siema koleżanko",
    "Ale bym się z nią zapoznał",
    "Zapalimy malboraska",
    "Troche koka koli",
    "pach pach"
  ];

  zmienWiadomosc() {
    this.wiadomosc = this.komunikaty[this.indeks];
    this.indeks++;
    if(this.indeks >= this.komunikaty.length) {
      this.indeks = 0;
    }
  }

  zwiekszLicznik() {
    this.licznik++;
  }

  produkty: string[] = [];
  nowyProdukt: string = "";

  dodajProdukt() {
    if (this.nowyProdukt.trim()) {
      this.produkty.push(this.nowyProdukt);
      this.nowyProdukt = "";
    }
  }

  usunProdukt(indeks: number) {
    this.produkty.splice(indeks, 1);

  }
}

